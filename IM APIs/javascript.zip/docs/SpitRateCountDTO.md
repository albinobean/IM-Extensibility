# InMomentPublicRestApi.SpitRateCountDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unitNumber** | **String** |  | [optional] 
**periodCount** | **Number** |  | [optional] 
**lastSpitRateCount** | **Number** |  | [optional] 
**spitRateTimestamp** | **Date** |  | [optional] 


