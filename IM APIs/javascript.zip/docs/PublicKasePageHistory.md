# InMomentPublicRestApi.PublicKasePageHistory

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**timestamp** | **Number** | Timestamp of history item as a unix timestamp | [optional] 
**performer** | [**PublicKaseEmployee**](PublicKaseEmployee.md) |  | [optional] 
**comment** | **String** |  | [optional] 
**type** | **String** |  | [optional] 


