# InMomentPublicRestApi.TagDTOTagCategory

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**tags** | [**[TagDTO]**](TagDTO.md) |  | [optional] 
**name** | **String** |  | [optional] 
**label** | **String** |  | [optional] 
**enabled** | **Boolean** |  | [optional] 
**visibleInInbox** | **Boolean** |  | [optional] 


