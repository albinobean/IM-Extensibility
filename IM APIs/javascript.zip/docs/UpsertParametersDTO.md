# InMomentPublicRestApi.UpsertParametersDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


