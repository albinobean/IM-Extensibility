# InMomentPublicRestApi.CaseOrgOrgIdCasesCreationTime

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**begin** | **Number** |  | [optional] 
**end** | **Number** |  | [optional] 


