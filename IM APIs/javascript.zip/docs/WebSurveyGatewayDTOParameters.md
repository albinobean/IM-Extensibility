# InMomentPublicRestApi.WebSurveyGatewayDTOParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**alias** | **String** |  | [optional] 
**promptId** | **String** |  | [optional] 
**promptName** | **String** |  | [optional] 
**sourceType** | **String** |  | [optional] 
**defaultParamValue** | **String** |  | [optional] 


