# InMomentPublicRestApi.UnitDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**externalId** | **String** |  | [optional] 
**enabled** | **Boolean** |  | [optional] 
**contactName** | **String** |  | [optional] 
**contactPhone** | **String** |  | [optional] 
**contactEmail** | **String** |  | [optional] 


