# InMomentPublicRestApi.ApiException

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorDescription** | **String** |  | [optional] 
**error** | [**ErrorCode**](ErrorCode.md) |  | [optional] 


