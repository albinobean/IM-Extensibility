# InMomentPublicRestApi.UpsertApiResultDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


