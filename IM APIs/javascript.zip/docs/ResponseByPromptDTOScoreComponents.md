# InMomentPublicRestApi.ResponseByPromptDTOScoreComponents

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fieldId** | **Number** |  | [optional] 
**points** | **Number** |  | [optional] 
**weight** | **Number** |  | [optional] 


