# InMomentPublicRestApi.PublicKasePage

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_number** | **Number** |  | [optional] 
**size** | **Number** |  | [optional] 
**totalPages** | **Number** |  | [optional] 
**numberOfElements** | **Number** |  | [optional] 
**totalElements** | **Number** |  | [optional] 
**first** | **Boolean** |  | [optional] 
**last** | **Boolean** |  | [optional] 
**content** | [**[PublicKasePageContent]**](PublicKasePageContent.md) |  | [optional] 


