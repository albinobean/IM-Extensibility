# InMomentPublicRestApi.ResponseByPromptDTOScores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**scoreFieldId** | **Number** |  | 
**scoreName** | **String** |  | [optional] 
**points** | **Number** |  | [optional] 
**pointsPossible** | **Number** |  | [optional] 
**score** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 
**scoreComponents** | [**[ResponseByPromptDTOScoreComponents]**](ResponseByPromptDTOScoreComponents.md) |  | [optional] 


