# InMomentPublicRestApi.SurveyInitInboundPhoneParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | Parameter keys must be unique. | [optional] 
**value** | **String** |  | [optional] 


