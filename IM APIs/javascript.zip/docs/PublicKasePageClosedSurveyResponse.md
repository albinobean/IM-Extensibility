# InMomentPublicRestApi.PublicKasePageClosedSurveyResponse

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resolved** | **Boolean** |  | [optional] [default to false]
**reasonClosedWithoutResolution** | **String** |  | [optional] 
**customerContacted** | **Boolean** |  | [optional] [default to false]
**reasonClosedWithoutContact** | **String** |  | [optional] 
**customerMood** | **Number** |  | [optional] 
**employeeMood** | **Number** |  | [optional] 
**recommendations** | **String** |  | [optional] 
**rootCause** | **String** |  | [optional] 
**comments** | **String** |  | [optional] 


