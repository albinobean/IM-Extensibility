# InMomentPublicRestApi.SyncBatch

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


