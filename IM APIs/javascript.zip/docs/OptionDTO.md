# InMomentPublicRestApi.OptionDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**externalId** | **String** |  | [optional] 
**label** | **String** |  | [optional] 
**localizedLabel** | [**[LocalizedStringDTO]**](LocalizedStringDTO.md) |  | [optional] 
**ordinalLevel** | **Number** |  | [optional] 


