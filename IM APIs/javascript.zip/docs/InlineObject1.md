# InMomentPublicRestApi.InlineObject1

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**organizationObjectId** | **Number** |  | [optional] 
**feedbackChannelId** | **Number** |  | [optional] 
**periodBeginDate** | **Date** |  | [optional] 
**units** | [**[SpitRateBulkUnitCountsUnits]**](SpitRateBulkUnitCountsUnits.md) |  | [optional] 


