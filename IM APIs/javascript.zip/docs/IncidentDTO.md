# InMomentPublicRestApi.IncidentDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**dateTime** | **Date** |  | [optional] 
**dateTimeUTC** | **Date** |  | [optional] 
**userAccountId** | **Number** |  | 
**userAccountFirstName** | **String** |  | [optional] 
**userAccountLastName** | **String** |  | [optional] 
**userAccountEmail** | **String** |  | [optional] 
**comment** | **String** |  | 
**incidentManagementState** | [**IncidentManagementState**](IncidentManagementState.md) |  | 


