# InMomentPublicRestApi.ResponseDTOSocialReviewRatings

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **Number** |  | [optional] 
**type** | **String** |  | [optional] 


