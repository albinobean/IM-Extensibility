# InMomentPublicRestApi.AnswerDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**fieldId** | **Number** |  | [optional] 
**fieldName** | **String** |  | [optional] 
**fieldText** | **String** |  | [optional] 
**fieldLabel** | **String** |  | [optional] 
**fieldType** | **String** |  | [optional] 
**literalValue** | **String** |  | [optional] 
**option** | [**OptionDTO**](OptionDTO.md) |  | [optional] 
**commentId** | **Number** |  | [optional] 
**commentType** | **String** |  | [optional] 
**commentArchived** | **Boolean** |  | [optional] 
**optionId** | **Number** |  | [optional] 


