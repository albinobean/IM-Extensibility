# InMomentPublicRestApi.UserAccountDTODashboardGroups

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 


