# InMomentPublicRestApi.InlineObject3

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gatewayAlias** | **String** | The alias of a inbound phone survey gateway. | 
**parameters** | [**[SurveyInitInboundPhoneParameters]**](SurveyInitInboundPhoneParameters.md) |  | [optional] 


