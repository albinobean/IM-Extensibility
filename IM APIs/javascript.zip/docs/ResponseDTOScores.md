# InMomentPublicRestApi.ResponseDTOScores

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**score** | **Number** |  | [optional] 
**points** | **Number** |  | [optional] 
**pointsPossible** | **Number** |  | [optional] 
**totalWeight** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 
**fieldId** | **Number** |  | [optional] 
**fieldName** | **String** |  | [optional] 
**scoreComponents** | [**[ResponseByPromptDTOScoreComponents]**](ResponseByPromptDTOScoreComponents.md) |  | [optional] 


