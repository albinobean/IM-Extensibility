# InMomentPublicRestApi.InlineObject

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**creationTime** | [**CaseOrgOrgIdCasesCreationTime**](CaseOrgOrgIdCasesCreationTime.md) |  | [optional] 
**lastModifiedTime** | [**CaseOrgOrgIdCasesCreationTime**](CaseOrgOrgIdCasesCreationTime.md) |  | [optional] 


