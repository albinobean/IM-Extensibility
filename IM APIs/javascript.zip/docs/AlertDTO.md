# InMomentPublicRestApi.AlertDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**alertId** | **Number** |  | [optional] 
**name** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**triggerType** | **String** |  | [optional] [default to &#39;DEFAULT&#39;]
**triggerFieldId** | **Number** |  | [optional] 
**triggerFieldName** | **String** |  | [optional] 



## Enum: TriggerTypeEnum


* `DEFAULT` (value: `"DEFAULT"`)

* `FIELD` (value: `"FIELD"`)




