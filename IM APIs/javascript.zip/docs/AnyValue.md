# InMomentPublicRestApi.AnyValue

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


