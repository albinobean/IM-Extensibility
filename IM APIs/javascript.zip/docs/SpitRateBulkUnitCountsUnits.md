# InMomentPublicRestApi.SpitRateBulkUnitCountsUnits

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unitNumber** | **String** |  | [optional] 
**lastSpitRateDate** | **Date** |  | [optional] 


