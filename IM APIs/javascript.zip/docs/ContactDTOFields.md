# InMomentPublicRestApi.ContactDTOFields

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fieldId** | **Number** | ID of the DataField. Must be a CrmField in the organization of the contact. | [optional] 
**value** | **Object** |  | [optional] 


