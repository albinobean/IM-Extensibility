# InMomentPublicRestApi.ContactDTOAddress

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line1** | **String** | First line of the address. | [optional] 
**line2** | **String** | Second line of the address. | [optional] 
**city** | **String** | City of the address. | [optional] 
**state** | **String** | State of the address. | [optional] 
**country** | **String** | Country of the address. | [optional] 
**postalCode** | **String** | Postal Code of the address. | [optional] 


