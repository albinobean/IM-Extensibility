# InMomentPublicRestApi.InlineObject2

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**noteId** | **String** |  | [optional] 
**utcTimestamp** | **Date** |  | 
**userTimestamp** | **Date** |  | 
**userId** | **Number** |  | 
**comment** | [**[LocalizedStringDTO]**](LocalizedStringDTO.md) |  | 
**incidentState** | [**IncidentManagementState**](IncidentManagementState.md) |  | 


