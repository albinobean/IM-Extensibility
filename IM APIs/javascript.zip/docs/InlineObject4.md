# InMomentPublicRestApi.InlineObject4

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gatewayAlias** | **String** |  | 
**parameters** | [**[SurveyInitInboundParameters]**](SurveyInitInboundParameters.md) |  | [optional] 
**expireHours** | **Number** |  | [optional] 
**uniqueKey** | **String** |  | [optional] 


