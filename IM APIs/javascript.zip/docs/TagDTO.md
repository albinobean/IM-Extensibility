# InMomentPublicRestApi.TagDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Number** |  | [optional] 
**tagCategory** | [**TagDTOTagCategory**](TagDTOTagCategory.md) |  | [optional] 
**name** | **String** |  | [optional] 
**label** | **String** |  | [optional] 
**enabled** | **Boolean** |  | [optional] 
**visibleInInbox** | **Boolean** |  | [optional] 


