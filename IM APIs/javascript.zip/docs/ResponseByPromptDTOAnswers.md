# InMomentPublicRestApi.ResponseByPromptDTOAnswers

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**promptId** | **Number** | ID of the prompt for this answer. | 
**answerValue** | **String** | The string representation of the answer. For categorical prompts, this should be the DTMF code for the specific answer option. | [optional] 


