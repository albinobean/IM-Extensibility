# InMomentPublicRestApi.LocalizedStringDTO

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**locale** | **String** |  | [optional] 
**value** | **String** |  | [optional] 


