# InMomentPublicRestApi.IncidentManagementState

## Enum


* `OPEN` (value: `"OPEN"`)

* `IN_PROCESS` (value: `"IN_PROCESS"`)

* `CLOSED` (value: `"CLOSED"`)


