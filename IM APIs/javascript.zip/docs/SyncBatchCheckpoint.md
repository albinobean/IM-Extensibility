# InMomentPublicRestApi.SyncBatchCheckpoint

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**checkpoint** | **Blob** |  | [optional] 


