# InMomentPublicRestApi.SurveyInitOutboundParameters

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **String** | Parameter keys must be unique. The following parameter keys are reserved: outbound_followup_email_address, outbound_followup_phone_number, outbound_followup_phone_number2 | [optional] 
**value** | **String** |  | [optional] 


