# InMomentPublicRestApi.ErrorCode

## Enum


* `server_error` (value: `"server_error"`)

* `invalid_request` (value: `"invalid_request"`)

* `access_denied` (value: `"access_denied"`)


