# InMomentPublicRestApi.UserAccountDTOLocale

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**language** | **String** |  | [optional] 
**country** | **String** |  | [optional] 
**variant** | **String** |  | [optional] 
**display** | **String** |  | [optional] 
**isInternal** | **Boolean** |  | [optional] 


